"""Workflow generator infrastructure layer."""
