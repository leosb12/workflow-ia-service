"""Reusable LLM integration helpers."""
