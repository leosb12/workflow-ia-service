"""Workflow generator domain layer."""
