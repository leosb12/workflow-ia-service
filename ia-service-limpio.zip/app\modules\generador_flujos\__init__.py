"""Workflow generator module."""
