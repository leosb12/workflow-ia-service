"""Shared Pydantic schemas."""
