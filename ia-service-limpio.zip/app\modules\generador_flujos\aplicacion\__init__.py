"""Workflow generator application layer."""
